# R1 proposal: settle the original cancelled OpenCode V2 admission within its original request deadline

Status: INERT DESIGN, awaiting root R1. Read-only source review; no production, test, dependency, archive, app pin, workflow, index or Git ref mutation was performed by this reviewer. No code, compiler, test, provider executable or package command was run. Reviewer: `/root/provider_cut_design`.

## Exact evidence and ownership

The producer source is `agent-teams-ai/old-provider-implementations` at `b19494fd2de47538a1c9315e338199ff41bbe497`. Root independently refreshed Draft PR8 and prepared the clean official Git checkout at `/workspace/scratch/f45fed8e9067/old-provider-implementations`; the reviewed sixteen exact GitHub file snapshots all match that checkout byte for byte. The snapshot manifest is `provider-admission-r1-source/source-manifest.json`, SHA256 `896e42bf8a545f019f8a5a25585c8225c0416ae0a6d341e7340e92e63a6adc89`.

Relevant production preimages, relative to `packages/provider-implementations/src/features/provider-session-implementation/adapters/opencode-protocol/`:

| Existing owner | Git blob | SHA256 |
| --- | --- | --- |
| `v2-request-admission.ts` | `9d44e76485c4ff66472f38b33446eb80856e445f` | `d936e012b2805ace0ef2b4bb3317932e9f81df539f21ca27a528fc4ca7c28630` |
| `v2-execution-transport.ts` | `b444ff0e25249b95947fca316d108b50ae36800e` | `dc3d67341fc27263b776a8f446d84b9006b9adfc350f77126d4e320254af8463` |
| `v2-control-transport.ts` | `5455d60b4ac641334698f99ed085215a759e7771` | `5b5624b7f2100afe75305d955017e7e887e60512c012bbff29303f1c81bea02d` |

The existing unchanged native-cut owner is blob `b51e488c96f17829a216199a6eb32e0b74857054`; driver owner is blob `f91ba4637d3444775db71d8e891ee6e361e420f4`; bounded await owner is blob `86c04808f56a21ecf67d7ae9582e360233f49bde`. Root/app source remains independently owned. App controlled suite `test/features/agent-backend/hostOpenCodeV2ModelProbeLifecycle.test.ts`, SHA256 `eac52e13a12e00337f9c03bb541b812e037757ffe1d855abeb698bcd8797b95d`, is evidence only until an independently qualified producer archive is adopted.

Read instructions: exact producer `AGENTS.md`, feature README, OpenCode adapter README, root/package scripts and CI workflow. Consumer policy, custody and lifecycle remain caller-owned; provider protocol mechanisms remain in the existing adapter. Public names/exports remain compatible. No engine/orchestrator dependency, release or real Claude/Codex execution is permitted. Normal provider checks use disposable fixtures, pinned pnpm11.18.0 and CI Node24.21.0/26.11.1.

## What is established

`createV2RequestAdmission.acquire` creates exactly one tracked promise, `work`, around the original caller's `beforeRequest(signal)`. Its fulfillment/rejection handlers clear `pending`; fulfillment validates and owns the returned synchronous release callback. `close` releases at most once, and late acquisition after close releases through the same original function. Unknown release remains unknown.

The first `boundV2Request(work, remaining, signal)` can reject from the abort listener before the original callback's complete promise chain settles. The current catch immediately emits `ExecutionTransportFailure('cleanup_unknown', 'unknown')` whenever `pending` is still true. The native-cut wrapper can wait for the original fetch rejection for its existing bounded cleanup interval, but that rejection already contains this irreversible classification. The driver correctly latches it; its latch is not the correction target.

The app's third controlled schedule returns the same second custody promise from its own actual abort listener. Its fixture marker precedes cut failure, and the original Host request drain completes before driver close, yet the final cut reports unknown and driver close fails. The marker itself is not direct observation of private lease release at `acquire.catch`. Awaiting `work` would observe the full Host callback chain, including its catch that releases the original Host reservation before rejection. This is the source invariant behind the proposal.

This does not prove the unobserved admission/fetch/body substage of the original Linux3f native failure, a filesystem cause, or the outcome of the next native run.

## Proposed exact production scope: three existing owners

### 1. Preserve each original request's absolute cutoff in both wires

In `OpenCodeV2ExecutionFetch.request`, retain the existing timer's absolute cutoff at the existing timer-creation point: the smaller of the unchanged context deadline and thirty seconds from that point. Schedule the same existing controller timer against the remainder of that cutoff, and pass that cutoff through the already-existing `deadline` argument of `createV2RequestAdmission`. Do not move timer creation before/after another admission stage.

Do the equivalent at the existing timer-creation point in the inner `request` of `createV2ControlWire`. Its timer currently starts before body consumption; preserve that placement, so admission settlement cannot gain time by starting its own window later. Pass this original request cutoff to admission, not the possibly later config/context deadline. Leave the other read bounds, request validation, credentials, mutation fences, byte budgets and finally paths unchanged.

These are retained local cutoff values for existing timers, not additional timers or new timeout allowances. The thirty-second constant and context limits do not grow. No deadline is based on the moment an abort is caught. A shorter original context deadline still wins. At an already-expired request cutoff, there is no settlement allowance left.

### 2. Await only the original tracked admission promise before first classification

Change only the catch in `createV2RequestAdmission.acquire`:

1. The existing no-pending path remains unchanged.
2. If the original `work` is still pending after actual signal abort and the original request cutoff is still in the future, join that same `work` through the existing `boundV2Request` helper, using only `deadline - Date.now()` and no already-aborted signal. Do not invoke `beforeRequest` again, replace its promise, read credentials, create HTTP work or obtain another lease.
3. A non-abort timeout, an expired cutoff, or work still pending at the end of the bounded settlement remains `cleanup_unknown`. A completion observed at or beyond the cutoff must not establish clean settlement.
4. If the original work rejects within that cutoff, preserve its typed uncertainty. In particular, neither `ExecutionTransportFailure` with `disposition: 'unknown'` nor `code: 'cleanup_unknown'` may be hidden by the wrapper's plain deadline error. Preserve an already-uncertain original caught error as well if the later original-work rejection is ordinary. Otherwise propagate the original-work rejection for the existing transport sanitizer.
5. If the original work fulfills within the cutoff, rethrow the original cancellation. The unchanged transport checks therefore cannot proceed to credentials or fetch; its unchanged finally calls the same `close`, which releases the original callback once. A throwing release overrides the cancellation with the existing unknown result.

The implementation should keep this as a local bounded catch, without adding a controller, timer abstraction, registry, owner, new exposed method, public argument, Session SPI capability or authority service. The helper's existing function signature and returned shape remain unchanged; only the meaning of the existing absolute deadline is made precisely equal to the existing request timer.

The fixed helper bound creates the same kind of finite wait timer it already uses; it does not introduce a later absolute deadline or additive cleanup budget. A pending callback can remain tracked after cutoff so late original lease release still occurs, as it does today. No already-emitted unknown is cleared by late settlement.

## Both cleanup owner paths and their unchanged limits

For execution requests, `request.catch` keeps its original controller abort, unclaimed-response and response-reader cancellation; `finally` clears the original timer/controller and calls admission close. Original response/body cancellation bounds remain one second. The tracked original admission work stays in `io`. `dispose` retains its original two-second join of pending requests plus IO and its nonempty-set refusal.

For control requests, the original pending set continues to track the admission work and request. `catch` aborts the original controller and retains uncertainty before creating the fixed public failure. `finally` keeps the original one-second reader cancellation and admission close. Its two-second dispose join is unchanged. No mutation/password/fetch may pass the existing post-admission and before-mutation checks after abort.

For native reads, `v2-native-cut.read` retains exactly its current original-fetch settlement deadline `min(original cut deadline, now + 1000)`. It joins the same original fetch promise. If admission does not settle within that outer cleanup bound, the cut still emits unknown even if the request's own deadline is later. A pending callback released only after this cut fails must still leave the driver unknown permanently. The final sibling all-settled join, priority of true unknown, body ownership and diagnostic capture remain unchanged.

The driver's sticky unknown, active-operation count, queue/currentness checks and close behavior remain unchanged. The Host's existing request reservation/drain, original close deadline, stop ownership and cleanup results remain unchanged. No late physical observation rewrites the already-emitted native or Host outcome.

Observable tradeoff: a directly used execution/control request whose admission ignores an early abort may now wait until its already-existing absolute request cutoff before returning unknown. It must not wait beyond the original thirty-second/context cutoff. In the native-cut path, the existing earlier cleanup bound still governs the cut result. This deliberate wait observes existing work; it does not start or replay work.

## Prospective tests and exact negative oracles

Extend the existing producer `v2-request-admission.test.ts` (blob `75724ab867f45471e58ee66a6fad2f3f73ca65f2`), retaining its original execution/control table and assertions. New controlled cases must exercise both actual wires, not a duplicate helper implementation:

- A real original abort listener resolves the same gate with one release callback. The request rejects cleanly as not submitted only after that original callback settles; credentials/fetch remain zero, callback invocation and release are exactly one, and dispose does not cause another release.
- The listener rejects the same gate with an ordinary private TEST error. Sanitized cancellation/refusal stays not submitted, no bytes/credentials escape, no second callback occurs, and pending cleanup completes.
- The listener instead rejects with typed unknown, including a cleanup-unknown code. It must remain unknown and never appear in the not-submitted weak set.
- A cooperatively returned release throws. Unknown remains; the release is attempted exactly once across repeated disposal, and native counters stay zero.
- An admission does not settle before the original request cutoff, while the config/context deadline is later. Prove the original request cutoff wins; the callback stays tracked and is released once when it eventually settles. Do not lengthen a production deadline or add retry to make this pass. A deterministic clock/controlled timer may drive the existing timer, but must preserve the original configured cutoff numerically and not substitute a smaller production budget.
- Retain the existing uncooperative late-lease, initial refusal, held-through-body, known-unknown and failed-release tests. The existing pending-admission negative may take longer because it intentionally refuses to settle until after failure; keep its oracle and explicit finite cleanup.

Extend the existing finite `v2-read-cut-settlement.test.ts` (blob `91bf91f4de69454b9c552bd012ae4c6b5886b0f7`) through `createDriverNative` and the real execution transport. Add a failed final sibling whose other original admission settles cooperatively on its own signal. The read must still fail, with the original ordinary failure; it cannot become a successful cut. Confirm exact request/admission/release counts and successful disposal. Add/retain the contrasting admission held beyond the existing outer cleanup cutoff: it remains unknown even after later release, and repeated driver disposal remains unknown. Keep the original real HTTP sibling test and direct public transport unknown/at-deadline cases.

The app's three existing schedules remain a second, distinct integration gate after producer qualification and archive adoption: both admitted HTTP siblings still close cleanly; the original gate held until after cut failure stays unknown; only the cooperative callback case should become a clean cancelled/read-failed cleanup with no protocol-dispose or driver-close unknown. Preserve all original session, prompt, message, HTTP and credential counts, final sibling paths, repeated-close invariants, sockets/listeners and test-root cleanup. Do not rewrite this third oracle against the old b194 archive.

These are prospective tests. This review did not execute RED, GREEN or a native experiment and does not claim any of them passed for the proposed source.

## Review, qualification and adoption route

Root must select the concrete scope and review its exact patch before any source mutation/publication. Retain the existing provider Draft PR8 and branch; refresh its lease before publication and preserve intervening changes. Root owns the continuous migration plan, evidence and Git ref publication. A later source patch and exact postimages need independent R2, relevant controlled regression checks, TS7-compatible type verification within current session rules and the unchanged full producer `pnpm check` gate under both exact CI Node versions. Do not weaken package/test/CI commands to obtain a pass.

Keep all original provider workflows and Draft guards byte-identical. No manual rerun/dispatch/cancel or real Claude/Codex CLI (including version checks). Capture the original successful exact-head producer checked-consumer archives and receipt, and independently review their source/bytes before any app adoption. Do not edit installed dist, locally repack a substitute, substitute credentials, broaden authority, activate a default Host, merge to main, advance Stage2 or publish a package/release.

Original native Linux, Windows readiness, P09 ARM, Desktop, final reviews and the authorized PR delivery chain remain separate unfinished obligations. This correction can establish its local cancellation invariant only; it cannot qualify those outcomes without their original resulting-source evidence.

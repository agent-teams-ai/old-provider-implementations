# R1: preserve the original lifecycle cancellation while settling a scoped request admission

Status: INERT SOURCE REVIEW; awaiting root acceptance before edits or execution. Owner: `/root/provider_cut_design`. No source, dependency, archive, app pin/oracle, index/ref or workflow has been changed by this investigation. No test or compiler was run for this R1.

## Exact current inputs and retained failure

Producer checkout is clean at `e458b7f5513a55122905205bd22bcb25977643b0`. Exact source preimages and evidence hashes are in `provider-admission-lifecycle-r1-inputs.json`, SHA256 `966f7c7a4bf8c338eebf8143c65ed2ceb500c6a083b731ae0d89e4137b8f49a2`.

The resulting app integration run retained 23 passing tests and one failure in the original full ModelProbe lifecycle file. The unchanged case `pending original custody stays UNKNOWN after the existing drain bound and late release` timed out at its original 15000ms. Log `app-admission-final-vitest.log` SHA256 is `e8e26e9141f05d536997e5f8d66b48f77d8024f265b74e529ffb287f7aadd0d9`; result `app-admission-final-checks.json` SHA256 is `b61ebce25d8bbcb00f135a3a9acf611c281bc605a97d6dcb8976cc1606a0babf`.

The current entire app test source is SHA256 `789c73dcec0a1621088614b34bd1a3ef7fa1c3cd8bf24aeeec94d98e1b89931d`. Its three final-cut cases pass, including the separately reviewed cooperative oracle change. The pending original custody case, its 15-second test bound, existing five-second Host drain, assertions and fixture remain untouched. The old e458 source/packed checks, archives and this failing app run remain historical results; they must not be re-labelled as qualification of this correction.

## Exact producer cause

The custody fixture arms `holdNextCustody` after the original queue-preflight log response. Its next original `beforeRequest` is the prompt POST admission, so this operation is in `native.queue`, not in `readOpenCodeV2NativeCut`. The native-cut's separate one-second settlement cannot bound this path.

Host close aborts its own measurement signal immediately. The ignored custody callback still holds its original Host reservation. After the unchanged five-second Host drain refuses cleanup, Host calls the original `DriverSession.close`.

`DriverSession.close` first seals the original submit, aborts its original lifecycle controller and then awaits the original loop through `bounded(..., config.limits.timeoutMs)`. The loop is awaiting `protocol.queue` -> `createDriverNative.queue` -> the execution wire's original prompt request -> `admission.acquire`.

At e458, the first admission bound observes the combined request/lifecycle signal and rejects, but its new catch performs a second `boundV2Request(work, deadline - Date.now())` with no signal. This deliberately keeps waiting for the original callback after cancellation, up to the request's approximately 30-second cutoff. It also unintentionally ignores the existing driver's lifecycle shutdown. The request is therefore still inside acquire while DriverSession.close is waiting for its loop.

The execution wire's original two-second `dispose` join cannot resolve this cycle earlier: `native.queue` reaches that disposal in its finally only after the awaited request returns. The session's protocol disposal is later still, after the original loop. Nothing in the failed test releases custody until `closing` resolves; the test therefore reaches its 15-second limit. The approximately 30-second upper wait follows from source and configured deadlines; this investigation did not execute or measure a complete 30-second run.

The first design accepted direct-wire waiting through the original request cutoff but did not distinguish a scoped read/request abort from the already-existing lifecycle shutdown. This correction narrows that permission explicitly. It does not replace the original failed consumer oracle with a different one.

## Minimal production scope: the same three existing owners

1. In `v2-request-admission.ts`, add one optional, private helper argument carrying the existing transport context/lifecycle signal. It is not a new configuration field or caller callback. Feed that signal to the second existing `boundV2Request` only. The initial combined request bound and every error/release/pending branch remain unchanged.
2. In `v2-execution-transport.ts`, pass the already-captured `this.context.signal` through that private argument when constructing the existing admission.
3. In `v2-control-transport.ts`, pass the already-copied `config.signal` through that private argument at the corresponding existing call.

The relevant operation is equivalent to `await boundV2Request(work, deadline - Date.now(), lifecycleSignal)`. Both wires already retain the selected context signal; do not read a later caller mutation, create another controller, wrap/reinvoke `beforeRequest`, attach a new global listener, add a registry, add a policy service, or alter the request's public shape.

No new timer or numeric budget is introduced. Original request timer placement, captured request cutoff and context deadline remain exactly as published at e458. The existing bounded-await helper already handles an initially aborted signal and removes its one signal listener/timer on settlement. Its implementation remains byte-identical.

`V2RequestAdmission`, public transport/config types, package facades/exports and Session SPI do not change. The helper is an implementation module behind the existing package export map. Its internal generated declaration will reflect the private extra signal argument; do not misdescribe the next archive as only three changed JS members if that internal `.d.ts` also changes. Existing public declarations and all other archive members must be independently compared and the exact changed set reported.

## Required semantics and preserved owners

When only a scoped request/cut signal aborts while its original context signal is live, the existing settlement joins the same original callback, with the same original request cutoff. The cooperative final-read cancellation path therefore retains its clean failed-read result.

When the original context/lifecycle signal is already aborted, the second bound immediately refuses; if the original callback is still pending, the unchanged catch emits UNKNOWN. When context aborts after a scoped cancellation has already entered the second bound, that same original signal interrupts the wait. This must be tested separately; a one-time `if (context.aborted)` check is insufficient.

Pending original work remains tracked after refusal. Late fulfillment releases its exact original lease at most once. An UNKNOWN already emitted by the request, native cut or driver cannot become clean later. Typed unknown disposition, `cleanup_unknown` code, failed release, at-cutoff result and unsubmitted classification keep all e458 corrections.

Native-cut, driver, Session close, Host reservation/drain, body cleanup and dispose source remain byte-identical. Their budgets remain: native-cut `min(original cut deadline, now + 1000)`, existing body cleanup 1000ms, transport dispose 2000ms and the original Host five-second drain. No budget is added, summed, moved or extended.

For the failed app path, lifecycle abort again allows the request to report unknown while the callback is held. The existing queue finally then reaches its unchanged two-second wire drain; the original loop and close can finish with unknown while custody remains unreleased. The strongest acceptance check is the unchanged app pending-custody case, not an inferred clean producer close.

## Test scope and explicit origin correction

Change only the existing producer `v2-request-admission.test.ts`; keep `v2-read-cut-settlement.test.ts` byte-identical and run its existing real finite HTTP positive/negative cases as regression coverage. Three production files plus one existing test file is the proposed source scope. Root owns docs and subsequent publication/adoption.

The e458 cooperative table currently aborts `config.signal`, and its request-cutoff table does the same. Their successful wait expectations encoded the overly broad permission that caused this regression. Preserve those original bytes/logs as history, then explicitly rename and change these schedules to **scoped request cancellation under a live original context**:

- Extend only the local test fixture's request helper to accept the already-supported RequestInit signal for both actual wires.
- Give the cooperative table a live context controller and a distinct scoped request controller; abort only the request controller. Retain every return/reject/typed-unknown/cleanup-code/release-failure/at-cutoff oracle and exact invocation/release/credential/fetch counts.
- Give the 20000/60000 context-deadline table the same distinct signal origins. Keep its existing numeric virtual request/context cutoffs, callback hold and late release assertions. The live context still allows scoped settlement, with the original shorter request/context cutoff winning.
- Keep the original pre-e458 `revoked pending admission never reads credentials and releases late lease` case unchanged. It continues to exercise config/context abort with an unresolved callback.

Add two explicit schedules to that same both-wire test table:

1. **Original context shutdown while admission is held.** Invoke the real wire with its original context signal, wait for the actual callback to enter, keep its promise unresolved and abort that context. After draining the current microtasks/event-loop turn, the request must already have rejected with cleanup UNKNOWN and must not be in the not-submitted set. No credential/fetch/release may have occurred yet. Only after recording this original rejection may the fixture resolve the same gate; disposal must join its original work and release exactly once. Repeated disposal and inspecting the retained rejection must not clear or replay anything.
2. **Original context shutdown during scoped settlement.** Enter the same pending callback, abort a distinct scoped request signal and prove the original request is still waiting while context is live. Then abort the original context without advancing or renewing any timer. The same request must reject UNKNOWN before the held gate is released, with zero credentials/fetches. Release that same original gate afterward and retain the same at-most-once and sticky prior-result assertions.

These deterministic failure assertions expose e458 directly without waiting for its 30-second request timer or changing a production/test deadline. On e458 they must fail because the original request is still pending after lifecycle shutdown. Every failed-run finally must still release the original gate and join the original work so RED does not leak a timer/promise. Do not replace the old app timeout evidence with these quicker controlled tests.

## Qualification order

After root R1 acceptance, freeze the exact four-file patch and obtain independent R2. Record new lifecycle-schedule RED against exact e458 with the same test bytes, then GREEN against the correction. Run the full existing producer admission/read-cut files, the unchanged original full `pnpm check` under pinned Node24.21/pnpm11.18, and preserve the exact packed-consumer archives in a distinct TEST directory. Compiler execution must remain sequential with other heavy root steps.

Publish through the existing Draft provider PR and normal expected-SHA route after root review. Observe the original resulting-source CI on both pinned Node versions and original permitted native gates; no manual rerun/dispatch/cancel. Only root may subsequently adopt the exact qualified archive into the app. The entire unchanged current app lifecycle file must then pass, particularly the original pending-custody case at its unchanged 15000ms and all three final-cut schedules. Do not edit installed dist, locally substitute archives, increase the test deadline, bypass an UNKNOWN, or claim the original native Linux failure repaired from these controlled checks.
